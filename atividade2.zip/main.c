/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
//calculadora de ações basicas
int main(){
    char escolha;
    double n1, n2;
    printf("calculadora\n digite o primeiro numero: ");
    scanf("%lf", &n1);
    printf("escolha o operador:\n");
    printf("+ - soma\n");
    printf("- - subtração\n");
    printf("* - multiplicação\n");
    printf("/ - divisao\n");
    scanf(" %c", &escolha);
    printf("digite o segundo número: ");
    scanf("%lf", &n2);
    switch(escolha){
           case '+': 
           printf("O Resultado é: %2.lf \n", n1 + n2);
        break;
        
        case '-':
        printf("O Resultado é: %2.lf \n", n1 - n2);
        break;
        
        case '*':
        printf("O Resultado é: %2.lf \n", n1 * n2);
        break;
        
        case '/':
        if(n2 == 0){
        printf("erro: não se pode dividir por 0 \n");
        } else {
            if(fmod(n1, n2 == 0)){
                printf("O resultado é: %.0lf\n", n1 / n2);
            } else{
                printf("O resultado é: %.2lf\n", n1 / n2);
            }
        }
        break;
        default: 
        printf("operação invalida! \n");
        break;
}

    return 0;
}