/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//dias da semana
int main()
{ int numero;
    printf("digite um numero (1-7): \n");
    scanf(" %d", &numero);
    
    switch(numero){
        case 1:
        printf(" Domingo \n");
        break;
        
        case 2:
        printf(" segunda-feira \n");
        break;
        
        case 3:
        printf(" terca-feira \n");
        break;
        
        case 4:
        printf(" quarta-feira \n");
        break;
        
        case 5:
        printf(" quinta-feira \n");
        break;
        
        case 6:
        printf(" sexta-feira \n");
        break;
        
        case 7:
        printf(" sabado \n");
        break;
        
        default :
        printf("numero invalido \n");
        break;
    }

    return 0;
}
