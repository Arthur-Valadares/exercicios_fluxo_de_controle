/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
// sistema de autentificação e acesso
int main(){
    int senha, cargo;
    
    printf("Digite sua senha: ");
    scanf("%d", &senha);
    if(senha == 1234){
        printf("selecione seu cargo: \n");
        printf("1- Administrador \n");
        printf("2- Gerente \n");
        printf("3- Funcionario \n");
        scanf("%d", &cargo);
        switch(cargo){
            case 1:
            printf("Acesso total ao sistema\n");
            break;
            
            case 2:
            printf("Acesso parcial(relatórios e estoque)\n");
            break;
            
            case 3:
            printf("Acesso basico(apenas consultas)\n");
            break;
            
            default:
            printf("cargo invalido!");
            break;
        }
        
    } else {
        printf("Acesso negado! \n");
    }

    return 0;
}
